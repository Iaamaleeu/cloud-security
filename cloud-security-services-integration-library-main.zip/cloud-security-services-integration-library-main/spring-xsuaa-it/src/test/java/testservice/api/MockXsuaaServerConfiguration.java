package testservice.api;

import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.BeforeAll;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;

@TestPropertySource(properties = { "xsuaa.xsappname=java-hello-world", "xsuaa.clientid=sb-java-hello-world",
		"xsuaa.url=http://localhost:33195", "xsuaa.uaadomain=http://localhost:33195" })
public class MockXsuaaServerConfiguration {
	private static final int DEFAULT_PORT = 33195;
	private static MockWebServer server;

	@BeforeAll
	static void beforeAll() throws IOException {
		initServer();
	}

	private static void initServer() throws IOException {
		if (server == null) {
			server = new MockWebServer();
			server.setDispatcher(new XsuaaRequestDispatcher());
			server.start(DEFAULT_PORT);
		}
	}

}
