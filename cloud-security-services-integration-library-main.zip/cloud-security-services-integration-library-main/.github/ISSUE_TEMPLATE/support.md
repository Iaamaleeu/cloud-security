---
name: How to get Support
about: Please use SAP official support channels instead to get help. Use **BC-CP-CF-SEC-LIB** or **Security Client Libraries** components.
title: ''
labels: support
assignees: ''

---

Before opening Support Tickets please check the corresponding [Troubleshooting](/README.md#troubleshooting) section
of the Security Client Libraries.

If you still do not find the answer please use SAP official support channels to get help. Use **BC-CP-CF-SEC-LIB** or 
**Security Client Libraries** components. Github.com is not an official support channel.


